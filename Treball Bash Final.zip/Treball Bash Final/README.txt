﻿Aplicacio de gestió d'usuaris
 by Marc Fabregat


-L'aplicacio consta d'un menu amb les seguents opcions:

Crear:
	
	-Dins del menu crear trobaras les seguents opcions
	
		CSV: S'obrirà una finestra on podras sel·lecionar el fitxer CSV que tens al sistema e importar els usuaris
		
			NOTA: L'arxiu CSV NOMES ha de tindre dos columnes, usuari i contrassenya, separats per una coma(,)
		
			NOTA: En cas de faltar un camp o dos, no es realitzara cap operacio
	
		UnicUsuari: S'obrirà un petit formulari on introduiras en nom de l'usuari per iniciar sessió i la contrassenya
		
			NOTA: Te valors per defecte si algun camp es deixa buit, estan especificats al respectiu formulari
	
		Sortir:	Sortira de l'aplicacio

Borrar:
	
	-Dins del menu crear trobaras les seguents opcions
	
		CSV: S'obrirà una finestra on podras sel·lecionar el fitxer CSV que tens al sistema amb la llista d'usuaris a eliminar
		
			NOTA: L'arxiu CSV NOMES ha de tindre dos columnes, usuari i contrassenya, separats per una coma(,)
		
			NOTA: En cas de faltar un camp o dos, no es realitzara cap operacio
	
		UnicUsuari: S'obrirà un petit formulari on introduiras en nom de l'usuari a eliminar
		
			NOTA: No pot estar buit o no borrara res
	
		Sortir:	Sortira de l'aplicacio

Modificar:
	
	-Dins del menu crear trobaras les seguents opcions
	
		CSV: S'obrirà una finestra on podras sel·lecionar el fitxer CSV que tens al sistema amb la llista d'usuaris amb la contrassenya a modificar
		
			NOTA: L'arxiu CSV NOMES ha de tindre dos columnes, usuari i contrassenya, separats per una coma(,)
		
			NOTA: En cas de faltar un camp o dos, no es realitzara cap operacio
	
		UnicUsuari: S'obrirà un petit formulari on introduiras en nom de l'usuari a modificar i la contrassenya nova
		
			NOTA: No pot estar buit o no borrara res
		
			NOTA: La contrassenya te un valor per defecte si el camp es deixa buit, esta especificat al respectiu formulari
	Sortir:	Sortira de l'aplicacio

Llista:
	
	-Llistarà tots els usuaris del sistema

Sortir:	
	
	-Sortira de l'aplicacio




----NOTA----


Funciona en Ubuntu 18 i 16

No provat en versions anteriors (Possible fallo al modificar degut a la comanda)
